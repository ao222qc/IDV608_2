<?php

class LoginController{

	private $userInputName;
	private $userInputPassword;
	private $logInView;

	public function userTriedLogin(){

		$this->userInputName = $this->logInView->userNameLoginInput();

		echo $this->userInputName;

	}

	public function __construct(LoginView $logInView)
	{
		$this->logInView = $logInView;

	}


}